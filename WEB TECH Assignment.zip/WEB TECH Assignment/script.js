// script.js

function submitForm(event) {
        event.preventDefault();

        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;

        if (email == "" || password == "") {

            alert("Please fill out both feild");
            return;
        }

        alert("Sign-in successful!");

        window.location.href = "Home page.html";
}